#ifndef POWER_OF_TWO_H
#define POWER_OF_TWO_H

/* Function Prototype */
int raiseToPower(int n, int k);

#endif // POWER_OF_TWO_H
