#ifndef PALINDROME_H
#define PALINDROME_H

#include <iostream>

bool isPalindrome(std::string word);

#endif // PALINDROME_H
